/*
	Integrantes: 
	Mateus Benedini de Oliveira Santiago Prates.  Matrícula:11621BSI200
	Matheus Santiago Neto.  Matrícula:11621BSI252

*/

// Função para requisitar recursos
int requisicao_recursos(int pid, int recursos[]);

// Função para liberação de recursos
int libera_recursos(int pid, int recursos[]);
